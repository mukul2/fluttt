String payable_amount = "";
String docID = "";
String docNAME = "";
String docPhoto = "";
String type = "";
String CHAT_ROOM = "";